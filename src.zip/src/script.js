// ========== بيانات البرنامج ==========
let networks = JSON.parse(localStorage.getItem("networks") || '{}');
let currentNetwork = null;
let cards = JSON.parse(localStorage.getItem("cards") || '{}');
let log = JSON.parse(localStorage.getItem("salesLog") || '[]');
let sellCardCounters = {};
let trialCount = 0;
const maxTrials = 5;
let isActivated = false;

// ========== حذف الشبكات غير الصالحة ==========
function cleanEmptyNetworks() {
    let changed = false;
    for (const net in networks) {
        // حذف إذا الاسم فارغ أو ليس نص أو الفئات فارغة أو ليست مصفوفة
        if (
            !net.trim() ||
            !Array.isArray(networks[net].categories) ||
            networks[net].categories.length === 0 ||
            networks[net].categories.some(x => !x.trim())
        ) {
            delete networks[net];
            if (cards[net]) delete cards[net];
            log = log.filter(e => e.network !== net);
            changed = true;
        }
    }
    if (changed) {
        localStorage.setItem("networks", JSON.stringify(networks));
        localStorage.setItem("cards", JSON.stringify(cards));
        localStorage.setItem("salesLog", JSON.stringify(log));
    }
}

// ========== الأدوات المساعدة للألوان ==========
function getNetworkMainColor(networkName) {
    return (networks[networkName] && networks[networkName].color) || "#2196F3";
}

function getNetworkColor(networkName) {
    return (networks[networkName] && networks[networkName].color) || "#e1f5fe";
}

function getContrastTextColor(bgColor) {
    if (!bgColor) return "#fff";
    bgColor = bgColor.replace('#', '');
    if (bgColor.length === 3) bgColor = bgColor.split('').map(c => c + c).join('');
    const r = parseInt(bgColor.substr(0,2),16);
    const g = parseInt(bgColor.substr(2,2),16);
    const b = parseInt(bgColor.substr(4,2),16);
    const yiq = ((r*299)+(g*587)+(b*114))/1000;
    return (yiq >= 180) ? '#222' : '#fff';
}

// ========== تحديث لون الواجهة ==========
function updateThemeColor() {
    const color = getNetworkMainColor(currentNetwork);
    document.documentElement.style.setProperty('--main-color', color);

    // الهيدر
    const header = document.querySelector('header');
    header.style.background = color;
    header.style.borderBottomLeftRadius = "24px";
    header.style.borderBottomRightRadius = "24px";
    header.style.transition = "background 0.5s, border-radius 0.5s";

    // زر البيع
    document.querySelectorAll('.sell-btn').forEach(btn => {
        btn.style.background = color;
        btn.style.transition = "background 0.5s";
    });

    // المودال
    document.querySelectorAll('.modal-content').forEach(m => {
        m.style.borderRadius = "20px";
        m.style.transition = "border-radius 0.4s";
    });

    // بطاقات البيع
    document.querySelectorAll('.sales-card').forEach(card => {
        card.style.borderRadius = "20px";
        card.style.transition = "border-radius 0.4s";
        card.style.borderColor = color;
    });
}

// ========== إحصائيات الشبكة ==========
function updateStats() {
    const statsSection = document.getElementById("stats-section");
    if (!currentNetwork || !networks[currentNetwork]) return;
    const cats = networks[currentNetwork].categories;
    statsSection.innerHTML = cats.map(cat => {
        const total = (cards[currentNetwork] && cards[currentNetwork][cat]) ? cards[currentNetwork][cat].length : 0;
        return `<div class="stat-circle" style="background:${getNetworkMainColor(currentNetwork)}">${cat}<br><span style="font-size:19px">${total}</span></div>`;
    }).join('');
}

// ========== تحديد الشبكة ==========
function updateNetworkSelect() {
    const selectElement = document.getElementById("network-select");
    const filterSelectElement = document.getElementById("filter-network");

    selectElement.innerHTML = Object.keys(networks).map(net => `<option value="${net}">${net}</option>`).join("");
    filterSelectElement.innerHTML = `<option value="">الكل</option>` + Object.keys(networks).map(net => `<option value="${net}">${net}</option>`).join("");

    selectElement.value = currentNetwork || Object.keys(networks)[0];
    updateCategories();
}

// ========== الفئات ==========
function updateCategories() {
    currentNetwork = document.getElementById("network-select").value;
    updateStats();
    renderSalesCards();
    updateThemeColor();
}

// ========== سجل العمليات ==========
function updateLog(showAll = false) {
    const filterNetwork = document.getElementById("filter-network").value;
    const searchValue = (document.getElementById("search-log")?.value || "").trim();
    const table = document.getElementById("sales-log");
    table.innerHTML = "";
    let entries = log.filter(e => !filterNetwork || e.network === filterNetwork);
    // بحث مرن في الكرت أو الفئة أو الشبكة
    if (searchValue) {
        const q = searchValue.toLowerCase();
        entries = entries.filter(e =>
            (e.code && e.code.toLowerCase().includes(q)) ||
            (e.category && e.category.toLowerCase().includes(q)) ||
            (e.network && e.network.toLowerCase().includes(q))
        );
    }
    entries = showAll ? entries.slice().reverse() : entries.slice(-5).reverse();
    entries.forEach(entry => {
        const rowColor = getNetworkColor(entry.network) + "12";
        const badgeBg = getNetworkColor(entry.network);
        const badgeText = getContrastTextColor(badgeBg);
        table.innerHTML += `<tr style="background:${rowColor};">
            <td>${entry.code}</td>
            <td>${entry.category}</td>
            <td>
                <span 
                    class="network-badge"
                    style="background:${badgeBg}; color:${badgeText}; border: 2px solid ${badgeBg};"
                >
                    ${entry.network}
                </span>
            </td>
            <td>${entry.date}</td>
            <td>${entry.time}</td>
        </tr>`;
    });
    updateTotalSales();
}

// ========== إجمالي المبيعات ==========
function updateTotalSales() {
    let total = 0;
    for (const entry of log) {
        if (
            networks[entry.network] &&
            networks[entry.network].prices &&
            networks[entry.network].prices[entry.category]
        ) {
            total += networks[entry.network].prices[entry.category];
        }
    }
    const badge = document.getElementById("total-sales");
    if (badge) badge.textContent = `إجمالي المبيعات: ${total} ريال`;
}

// ========== بطاقات البيع ==========
function renderSalesCards() {
    const salesCards = document.getElementById("sales-cards");
    if (!currentNetwork || !networks[currentNetwork]) return salesCards.innerHTML = "";
    const cats = networks[currentNetwork].categories;
    salesCards.innerHTML = cats.map(cat => {
        const available = (cards[currentNetwork] && cards[currentNetwork][cat]) ? cards[currentNetwork][cat].length : 0;
        if (!sellCardCounters[cat]) sellCardCounters[cat] = 1;
        return `
        <div class="sales-card" id="sales-card-${cat}">
            <div class="cat-title">${cat}</div>
            <div class="available">المتوفر: <b>${available}</b></div>
            <div class="counter">
                <button onclick="adjustCardCounter('${cat}', -1)">-</button>
                <span id="sell-count-${cat}">${sellCardCounters[cat]}</span>
                <button onclick="adjustCardCounter('${cat}', 1)">+</button>
            </div>
            <button class="sell-btn" onclick="sellCardsCard('${cat}')" ${available === 0 ? "disabled" : ""}>بيع</button>
        </div>`;
    }).join('');
}

// ========== عداد البطاقة ==========
function adjustCardCounter(cat, val) {
    sellCardCounters[cat] = Math.max(1, (sellCardCounters[cat] || 1) + val);
    const available = (cards[currentNetwork] && cards[currentNetwork][cat]) ? cards[currentNetwork][cat].length : 0;
    if (sellCardCounters[cat] > available) sellCardCounters[cat] = available;
    document.getElementById("sell-count-" + cat).innerText = sellCardCounters[cat];
}

// ========== بيع الكروت ==========
function sellCardsCard(cat) {
    if (!cards[currentNetwork] || !cards[currentNetwork][cat] || cards[currentNetwork][cat].length === 0) {
        alert("لا توجد كروت متوفرة.");
        return;
    }
    const count = Math.min((sellCardCounters[cat] || 1), cards[currentNetwork][cat].length);
    const sold = cards[currentNetwork][cat].splice(0, count);
    localStorage.setItem("cards", JSON.stringify(cards));
    sold.forEach(code => {
        const now = new Date();
        log.push({
            code,
            category: cat,
            network: currentNetwork,
            date: now.toLocaleDateString(),
            time: now.toLocaleTimeString()
        });
    });
    localStorage.setItem("salesLog", JSON.stringify(log));
    updateStats();
    renderSalesCards();
    updateLog();
    updateTotalSales();
    displaySoldCardsFancy(sold, cat);
}

// ========== نافذة بيع الكروت ==========
function displaySoldCardsFancy(sold, cat) {
    const listElement = document.getElementById("sold-cards-list");
    const network = currentNetwork;
    const color = getNetworkMainColor(network);
    const price = (networks[network] && networks[network].prices && networks[network].prices[cat]) || 0;
    const total = sold.length * price;

    listElement.innerHTML = `
        <div style="margin-bottom:8px;">
            <strong>اسم الشبكة:</strong> <span style="color:${color}">${network}</span><br>
            <strong>الفئة:</strong> ${cat}<br>
            <strong>عدد الكروت المباعة:</strong> ${sold.length}<br>
            <strong>سعر الكرت:</strong> ${price} ريال<br>
            <strong>الإجمالي:</strong> ${total} ريال
        </div>
        <div style="margin-bottom:8px;">
            <strong>الكروت:</strong>
            <ol style="direction:ltr; text-align:left; margin-top:8px;">
                ${sold.map(code => `<li>${code}</li>`).join("")}
            </ol>
        </div>
    `;
    toggleModal('sold-modal');
}

// ========== نسخ ومشاركة الكروت المباعة ==========
function copySoldCards() {
    const text = document.getElementById("sold-cards-list").innerText;
    navigator.clipboard.writeText(text).then(() => alert("تم النسخ!"));
}
function shareSoldCards() {
    const text = document.getElementById("sold-cards-list").innerText;
    if (navigator.share) {
        navigator.share({ text });
    } else {
        copySoldCards();
    }
}

// ========== نافذة إضافة شبكة ==========
function addNetwork() {
    const name = document.getElementById("network-name").value.trim();
    const color = document.getElementById("network-color").value.trim() || "#2196F3";
    const categories = document.getElementById("network-categories").value.split(',').map(cat => cat.trim()).filter(Boolean);

    // حماية: عدم إضافة شبكة بدون اسم أو بدون فئات
    if (!name) {
        alert("يرجى كتابة اسم الشبكة.");
        return;
    }
    if (categories.length === 0) {
        alert("يرجى إدخال فئة واحدة على الأقل.");
        return;
    }
    if (networks[name]) {
        alert("اسم الشبكة موجود بالفعل.");
        return;
    }

    let prices = {};
    for (const cat of categories) {
        let price = prompt(`سعر الكرت في الفئة "${cat}"؟`, cat);
        price = parseInt(price) || 0;
        prices[cat] = price;
    }

    networks[name] = {
        categories: categories,
        prices: prices,
        color: color
    };
    localStorage.setItem("networks", JSON.stringify(networks));
    updateNetworkSelect();
    document.getElementById("network-name").value = '';
    document.getElementById("network-categories").value = '';
    document.getElementById("network-color").value = "#2196F3";
    alert("تم إضافة الشبكة بنجاح!");
    trialCount++;
    checkTrialLimit();
    toggleModal('network-modal');
}

// ========== تعبئة الكروت ==========
function updateFillNetworkAndCategories() {
    const fillNet = document.getElementById("fill-network");
    fillNet.innerHTML = Object.keys(networks).map(n => `<option value="${n}">${n}</option>`).join("");
    updateFillCategories();
}
function updateFillCategories() {
    const fillNet = document.getElementById("fill-network").value;
    const fillCat = document.getElementById("fill-category");
    if (!fillNet || !networks[fillNet]) return fillCat.innerHTML = "";
    fillCat.innerHTML = networks[fillNet].categories.map(c => `<option value="${c}">${c}</option>`).join("");
}
function fillCards() {
    const net = document.getElementById("fill-network").value;
    const cat = document.getElementById("fill-category").value;
    const raw = document.getElementById("fill-cards").value;
    if (!net || !cat || !raw.trim()) {
        alert("يرجى اختيار الشبكة والفئة وإدخال الكروت.");
        return;
    }
    const lines = raw.split('\n').map(x => x.trim()).filter(Boolean);
    if (!cards[net]) cards[net] = {};
    if (!cards[net][cat]) cards[net][cat] = [];
    const set = new Set(cards[net][cat]);
    let added = 0;
    for (let k of lines) {
        if (!set.has(k)) {
            cards[net][cat].push(k);
            set.add(k);
            added++;
        }
    }
    localStorage.setItem("cards", JSON.stringify(cards));
    updateStats();
    renderSalesCards();
    alert("تمت تعبئة " + added + " كرت بنجاح!");
    document.getElementById("fill-cards").value = "";
    toggleModal('fill-modal');
}

// ========== زر تقرير المبيعات ==========
function showReport() {
    renderReport();
    toggleModal('report-modal');
}

function renderReport() {
    const networkSales = {};
    const networkCatCount = {};
    const networkCatProfit = {};
    for (const entry of log) {
        const net = entry.network;
        const cat = entry.category;
        if (!networkSales[net]) networkSales[net] = 0;
        if (
            networks[net] &&
            networks[net].prices &&
            networks[net].prices[cat]
        ) {
            networkSales[net] += networks[net].prices[cat];
        }
        if (!networkCatCount[net]) networkCatCount[net] = {};
        if (!networkCatCount[net][cat]) networkCatCount[net][cat] = 0;
        networkCatCount[net][cat]++;
        if (!networkCatProfit[net]) networkCatProfit[net] = {};
        if (!networkCatProfit[net][cat]) networkCatProfit[net][cat] = 0;
        networkCatProfit[net][cat] += networks[net]?.prices?.[cat] || 0;
    }

    const reportDiv = document.getElementById("reports-section");
    reportDiv.innerHTML = `<div class="report-grid"></div>`;
    const grid = reportDiv.querySelector(".report-grid");

    Object.keys(networks).forEach(net => {
        const color = getNetworkMainColor(net);
        const textColor = getContrastTextColor(color);

        let mostCat = "";
        let mostCatCount = 0;
        if (networkCatCount[net]) {
            for (const cat in networkCatCount[net]) {
                if (networkCatCount[net][cat] > mostCatCount) {
                    mostCat = cat;
                    mostCatCount = networkCatCount[net][cat];
                }
            }
        }

        let catsHTML = "";
        if (networks[net].categories.length > 0) {
            catsHTML = networks[net].categories.map(cat => {
                const count = (networkCatCount[net] && networkCatCount[net][cat]) || 0;
                const profit = (networkCatProfit[net] && networkCatProfit[net][cat]) || 0;
                const isMax = mostCat === cat && mostCatCount > 0;
                return `<div class="cat-row">
                    <span>
                        <span class="cat-badge">${cat}</span>
                        ${isMax ? '<span class="cat-max">الأكثر مبيعًا</span>' : ''}
                    </span>
                    <span>
                        <span class="cat-sold">${count} كرت</span>
                        <span class="cat-profit">${profit} ريال</span>
                    </span>
                </div>`;
            }).join('');
        } else {
            catsHTML = `<div style="color:#888;font-size:13px;">لا توجد فئات لهذه الشبكة</div>`;
        }

        grid.innerHTML += `
            <div class="report-card">
                <div class="report-net-title">
                    <span class="report-net-badge" style="background:${color};color:${textColor};">${net}</span>
                </div>
                <div class="report-total">الإجمالي: ${networkSales[net] || 0} ريال</div>
                <div class="report-cats">${catsHTML}</div>
            </div>
        `;
    });
}

// ========== زر تعديل الشبكة ==========
function showEditNetworkModal() {
    populateEditNetworkList();
    toggleModal('edit-network-modal');
}

function populateEditNetworkList() {
    const sel = document.getElementById("edit-network-select");
    sel.innerHTML = Object.keys(networks).map(n => `<option value="${n}">${n}</option>`).join("");
    populateEditCategories();
}

function populateEditCategories() {
    const net = document.getElementById("edit-network-select").value;
    if (!net || !networks[net]) {
        document.getElementById("edit-network-categories").value = "";
        document.getElementById("edit-network-prices").innerHTML = "";
        document.getElementById("edit-network-name").value = "";
        document.getElementById("edit-network-color").value = "#2196F3";
        return;
    }
    document.getElementById("edit-network-name").value = net;
    document.getElementById("edit-network-categories").value = networks[net].categories.join(',');
    document.getElementById("edit-network-color").value = networks[net].color || "#2196F3";
    populateEditPrices();
}

function populateEditPrices() {
    const net = document.getElementById("edit-network-select").value;
    const cats = document.getElementById("edit-network-categories").value
        .split(',').map(x => x.trim()).filter(Boolean);
    let pricesHtml = "";
    cats.forEach(cat => {
        const price = (networks[net] && networks[net].prices && networks[net].prices[cat]) || 0;
        pricesHtml += `<label>${cat}: <input type="number" min="0" step="1" value="${price}"
            id="edit-price-${cat}"/> ريال</label> `;
    });
    document.getElementById("edit-network-prices").innerHTML = pricesHtml;
}

// حدث الأسعار عند تغيير الفئات نصياً
document.addEventListener("input", function(e){
    if (e.target.id === "edit-network-categories") populateEditPrices();
});

function saveNetworkEdit() {
    const oldNet = document.getElementById("edit-network-select").value;
    const newNet = document.getElementById("edit-network-name").value.trim();
    const newColor = document.getElementById("edit-network-color").value || "#2196F3";
    let cats = document.getElementById("edit-network-categories").value.split(',').map(x => x.trim()).filter(Boolean);

    // حماية: لا تعديل إذا الاسم أو الفئات فارغ
    if (!oldNet || !newNet) return alert("يرجى اختيار الشبكة وكتابة اسم جديد.");
    if (cats.length === 0) return alert("يرجى إدخال فئة واحدة على الأقل.");

    let prices = {};
    for (const cat of cats) {
        let price = parseInt(document.getElementById("edit-price-" + cat)?.value || "0");
        if (isNaN(price) || price < 0) return alert("يرجى إدخال سعر صحيح لكل فئة");
        prices[cat] = price;
    }

    if (oldNet !== newNet) {
        networks[newNet] = {...networks[oldNet], categories: cats, prices: prices, color: newColor};
        delete networks[oldNet];
        if (cards[oldNet]) {
            cards[newNet] = cards[oldNet];
            delete cards[oldNet];
        }
        log.forEach(e => { if (e.network === oldNet) e.network = newNet; });
        currentNetwork = newNet;
    } else {
        networks[oldNet].categories = cats;
        networks[oldNet].prices = prices;
        networks[oldNet].color = newColor;
    }
    localStorage.setItem("networks", JSON.stringify(networks));
    localStorage.setItem("cards", JSON.stringify(cards));
    localStorage.setItem("salesLog", JSON.stringify(log));
    updateNetworkSelect();
    updateStats();
    renderSalesCards();
    updateFillNetworkAndCategories();
    updateLog();
    alert("تم تعديل الشبكة بنجاح!");
    toggleModal('edit-network-modal');
}

// ========== حذف الشبكة ==========
function deleteNetwork() {
    const net = document.getElementById("edit-network-select").value;
    if (!net) return;
    if (!confirm(`هل أنت متأكد أنك تريد حذف الشبكة "${net}" مع كل بياناتها؟ لا يمكن التراجع!`)) return;

    // حذف من الشبكات
    delete networks[net];
    // حذف من الكروت
    if (cards[net]) delete cards[net];
    // حذف من السجل
    log = log.filter(e => e.network !== net);

    // تحديث التخزين
    localStorage.setItem("networks", JSON.stringify(networks));
    localStorage.setItem("cards", JSON.stringify(cards));
    localStorage.setItem("salesLog", JSON.stringify(log));

    // تحديث واجهة المستخدم
    // اختر شبكة أخرى إن وجدت
    const remaining = Object.keys(networks);
    currentNetwork = remaining.length ? remaining[0] : null;
    updateNetworkSelect();
    updateStats();
    renderSalesCards();
    updateFillNetworkAndCategories();
    updateLog();
    updateTotalSales();

    alert("تم حذف الشبكة مع جميع بياناتها!");
    toggleModal('edit-network-modal');
}

// ========== أدوات عامة ==========
function toggleModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.style.display = (modal.style.display === "flex") ? "none" : "flex";
    if (modalId === "fill-modal" && modal.style.display === "flex") {
        updateFillNetworkAndCategories();
    }
}

function updateTotal() {}

function checkTrialLimit() {}

// ========== بداية التشغيل ==========
window.onload = function() {
    cleanEmptyNetworks();
    if (Object.keys(networks).length === 0) {
        networks['شبكة افتراضية'] = { categories: ["100", "200", "300"], prices: { "100": 100, "200": 200, "300": 300 }, color: "#2196F3" };
        localStorage.setItem("networks", JSON.stringify(networks));
    }
    updateNetworkSelect();
    updateLog();
    updateTotal();
    updateFillNetworkAndCategories();
    updateTotalSales();
};

// إغلاق المودال عند الضغط خارج المحتوى
window.addEventListener('click', function(e){
    document.querySelectorAll('.modal').forEach(modal => {
        if (e.target === modal) modal.style.display = 'none';
    });
});